const API_BASE = "http://localhost:3000/api/auth";

// ------------------- REGISTER -------------------
async function registerUser() {
  const username = document.getElementById('reg-username').value;
  const email = document.getElementById('reg-email').value;
  const password = document.getElementById('reg-password').value;

  try {
    const res = await fetch(`${API_BASE}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password })
    });
    const data = await res.json();
    alert(data.message || JSON.stringify(data));
  } catch (err) {
    console.error(err);
    alert('Error registering user');
  }
}

document.getElementById('reg-btn').onclick = registerUser;

// ------------------- LOGIN -------------------
async function loginUser() {
  const email = document.getElementById('login-email').value;
  const password = document.getElementById('login-password').value;

  try {
    const res = await fetch(`${API_BASE}/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();
    if (data.token) {
      localStorage.setItem('token', data.token);
      alert('Login successful!');
    } else {
      alert(data.error || 'Login failed');
    }
  } catch (err) {
    console.error(err);
    alert('Error logging in');
  }
}

document.getElementById('login-btn').onclick = loginUser;

// ------------------- FORGOT PASSWORD -------------------
async function forgotPassword() {
  const email = document.getElementById('forgot-email').value;

  try {
    const res = await fetch(`${API_BASE}/forgot-password`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email })
    });
    const data = await res.json();
    alert(data.message || JSON.stringify(data));
  } catch (err) {
    console.error(err);
    alert('Error sending OTP');
  }
}

document.getElementById('forgot-btn').onclick = forgotPassword;

// ------------------- VERIFY OTP -------------------
async function verifyOtp() {
  const email = document.getElementById('otp-email').value;
  const otp = document.getElementById('otp-code').value;
  const newPassword = document.getElementById('otp-new-password').value;

  try {
    const res = await fetch(`${API_BASE}/verify-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, otp, newPassword })
    });
    const data = await res.json();
    alert(data.message || JSON.stringify(data));
  } catch (err) {
    console.error(err);
    alert('Error verifying OTP');
  }
}

document.getElementById('verify-otp-btn').onclick = verifyOtp;

// ------------------- UPDATE PROFILE -------------------
async function updateProfile() {
  const token = localStorage.getItem('token');
  if (!token) return alert('Please login first');

  const username = document.getElementById('update-username').value;
  const email = document.getElementById('update-email').value;
  const password = document.getElementById('update-password').value;

  try {
    const res = await fetch(`${API_BASE}/update-profile`, {
      method: 'PUT',
      headers: { 
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${token}`
      },
      body: JSON.stringify({ username, email, password })
    });
    const data = await res.json();
    alert(data.message || JSON.stringify(data));
  } catch (err) {
    console.error(err);
    alert('Error updating profile');
  }
}

document.getElementById('update-btn').onclick = updateProfile;

// ------------------- GET ACTIVITY LOG -------------------
async function getActivityLog() {
  const token = localStorage.getItem('token');
  if (!token) return alert('Please login first');

  try {
    const res = await fetch(`${API_BASE}/activity-log?limit=20`, {
      headers: { 'Authorization': `Bearer ${token}` }
    });
    const data = await res.json();
    const container = document.getElementById('activity-log');
    container.innerHTML = data.logs.map(log => 
      `<div>
        <strong>${log.action}</strong> - ${new Date(log.created_at).toLocaleString()} 
        <pre>${JSON.stringify(log.meta)}</pre>
      </div>`
    ).join('');
  } catch (err) {
    console.error(err);
    alert('Error fetching activity log');
  }
}

document.getElementById('activity-log-btn').onclick = getActivityLog;
