const API_BASE = "http://localhost:3000/api/auth";

// Register function
async function registerUser() {
  const username = document.getElementById('reg-username').value;
  const email = document.getElementById('reg-email').value;
  const password = document.getElementById('reg-password').value;
  const messageEl = document.getElementById('message');

  if (!username || !email || !password) {
    messageEl.textContent = 'Please fill in all fields';
    messageEl.style.color = 'red';
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/register`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ username, email, password })
    });

    const data = await res.json();

    if (res.ok) {
      messageEl.textContent = data.message || 'Registration successful!';
      messageEl.style.color = 'green';
      // optionally redirect after 2 seconds
      setTimeout(() => window.location.href = 'index.html', 2000);
    } else {
      messageEl.textContent = data.error || 'Registration failed';
      messageEl.style.color = 'red';
    }
  } catch (err) {
    console.error(err);
    messageEl.textContent = 'Server error. Try again later.';
    messageEl.style.color = 'red';
  }
}

// Bind event after DOM is ready
document.addEventListener('DOMContentLoaded', () => {
  const regBtn = document.getElementById('reg-btn');
  if (regBtn) regBtn.addEventListener('click', registerUser);
});


