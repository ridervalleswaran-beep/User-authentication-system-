const API_BASE = "http://localhost:3000/api/auth";

async function forgotPassword() {
  const email = document.getElementById("forgot-email").value;

  try {
    const res = await fetch(`${API_BASE}/forgot-password`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ email })
    });

    const data = await res.json();

    if (res.ok) {
      alert(data.message || "OTP sent successfully!");
      window.location.href = "reset-password.html";
    } else {
      alert(data.error || "Failed to send OTP");
    }
  } catch (err) {
    console.error("Error:", err);
    alert("Server error while sending OTP");
  }
}

document.getElementById("forgot-btn").addEventListener("click", forgotPassword);

