const API_BASE = "http://localhost:3000/api/auth";

document.getElementById('verify-otp-btn').onclick = async function () {
  const email = document.getElementById('otp-email').value;
  const otp = document.getElementById('otp-code').value;
  const newPassword = document.getElementById('otp-new-password').value;

  try {
    const res = await fetch(`${API_BASE}/verify-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, otp, newPassword })
    });
    const data = await res.json();
    alert(data.message || JSON.stringify(data));
    if (res.ok) window.location.href = "index.html";
  } catch (err) {
    console.error(err);
    alert('Error verifying OTP');
  }
};
