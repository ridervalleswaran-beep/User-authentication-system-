const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const Otp = require('../models/Otp');
const ActivityLog = require('../models/ActivityLog');
const { sendOtpEmail } = require('../helpers/email');

const generateOtp = () => (Math.floor(100000 + Math.random() * 900000)).toString();

// ---------------- REGISTER ----------------
exports.register = async (req, res) => {
  try {
    const { username, email, password } = req.body;
    const users = await User.findByEmail(email);
    if (users.length) return res.status(409).json({ error: 'Email already exists' });
    const hashed = await bcrypt.hash(password, 10);
    await User.create(username, email, hashed);
    return res.json({ message: 'User registered' });
  } catch (err) { console.error(err); return res.status(500).json({ error: 'Server error' }); }
};

// ---------------- LOGIN ----------------
exports.login = async (req, res) => {
  try {
    const { email, password } = req.body;
    const users = await User.findByEmail(email);
    if (!users.length) return res.status(400).json({ error: 'Invalid credentials' });
    const user = users[0];
    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).json({ error: 'Invalid credentials' });
    const token = jwt.sign({ id: user.id, email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
    return res.json({ message: 'Login successful', token });
  } catch (err) { console.error(err); return res.status(500).json({ error: 'Server error' }); }
};

// ---------------- FORGOT PASSWORD ----------------
exports.forgotPassword = async (req, res) => {
  try {
    const { email } = req.body;
    const users = await User.findByEmail(email);
    if (!users.length) return res.status(200).json({ message: 'If a matching account exists, an OTP has been sent.' });
    const user = users[0];
    await Otp.deleteAllForUser(user.id);
    const otp = generateOtp();
    await Otp.create(user.id, otp, 5);
    await sendOtpEmail(user.email, otp);
    await ActivityLog.create(user.id, 'forgot_password_requested', { ip: req.ip });
    return res.json({ message: 'If a matching account exists, an OTP has been sent.' });
  } catch (err) { console.error(err); return res.status(500).json({ error: 'Server error' }); }
};

// ---------------- VERIFY OTP ----------------
exports.verifyOtp = async (req, res) => {
  try {
    const { email, otp, newPassword } = req.body;
    const users = await User.findByEmail(email);
    if (!users.length) return res.status(400).json({ error: 'Invalid OTP or email' });
    const user = users[0];
    const record = await Otp.findValid(user.id);
    if (!record) return res.status(400).json({ error: 'No OTP found or expired' });
    if (record.used) return res.status(400).json({ error: 'OTP already used' });
    if (new Date(record.expires_at) < new Date()) return res.status(400).json({ error: 'OTP expired' });
    const match = await bcrypt.compare(otp, record.otp_hash);
    if (!match) return res.status(400).json({ error: 'Invalid OTP' });
    await Otp.markUsed(record.id);
    if (newPassword) {
      if (newPassword.length < 8) return res.status(400).json({ error: 'Password must be 8+ chars' });
      const hashed = await bcrypt.hash(newPassword, 10);
      await User.setPasswordById(user.id, hashed);
      await ActivityLog.create(user.id, 'password_reset', { ip: req.ip });
      return res.json({ message: 'Password reset successful' });
    }
    await ActivityLog.create(user.id, 'otp_verified', { ip: req.ip });
    return res.json({ message: 'OTP verified' });
  } catch (err) { console.error(err); return res.status(500).json({ error: 'Server error' }); }
};

// ---------------- UPDATE PROFILE ----------------
exports.updateProfile = async (req, res) => {
  try {
    const userId = req.user.id;
    const { username, email, password } = req.body;
    if (!username && !email && !password) return res.status(400).json({ error: 'No fields to update' });
    if (email) {
      const taken = await User.isEmailTakenByOther(email, userId);
      if (taken) return res.status(409).json({ error: 'Email already in use' });
    }
    const updates = {};
    if (username) updates.username = username;
    if (email) updates.email = email;
    if (password) updates.passwordHash = await bcrypt.hash(password, 10);
    await User.updateProfile(userId, updates);
    await ActivityLog.create(userId, 'profile_updated', { fields: Object.keys(updates) });
    return res.json({ message: 'Profile updated' });
  } catch (err) { console.error(err); return res.status(500).json({ error: 'Server error' }); }
};

// ---------------- GET ACTIVITY LOG ----------------
exports.getActivityLog = async (req, res) => {
  try {
    const logs = await ActivityLog.listForUser(req.user.id, 50);
    return res.json({ logs });
  } catch (err) { console.error(err); return res.status(500).json({ error: 'Server error' }); }
};
