const express = require('express');
const router = express.Router();
const { body } = require('express-validator');
const rateLimit = require('express-rate-limit');

const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');

// ------------------- Rate limiter -------------------
const forgotLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5,                   // limit each IP to 5 requests per windowMs
  message: { error: "Too many requests, please try again later." }
});

// ------------------- REGISTER -------------------
router.post(
  '/register',
  [
    body('username').notEmpty().withMessage('Username required'),
    body('email').isEmail().withMessage('Valid email required'),
    body('password').isLength({ min: 8 }).withMessage('Password must be at least 8 characters')
  ],
  authController.register
);

// ------------------- LOGIN -------------------
router.post(
  '/login',
  [
    body('email').isEmail().withMessage('Valid email required'),
    body('password').exists().withMessage('Password required')
  ],
  authController.login
);

// ------------------- FORGOT PASSWORD -------------------
router.post(
  '/forgot-password',
  forgotLimiter,
  [ body('email').isEmail().withMessage('Valid email required') ],
  authController.forgotPassword
);

// ------------------- VERIFY OTP -------------------
router.post(
  '/verify-otp',
  [
    body('email').isEmail().withMessage('Valid email required'),
    body('otp').isLength({ min: 6, max: 6 }).withMessage('OTP must be 6 digits')
    // newPassword is optional and checked inside controller
  ],
  authController.verifyOtp
);

// ------------------- UPDATE PROFILE -------------------
router.put(
  '/update-profile',
  authMiddleware,
  [
    body('email').optional().isEmail().withMessage('Invalid email'),
    body('password').optional().isLength({ min: 8 }).withMessage('Password must be at least 8 chars'),
    body('username').optional().notEmpty().withMessage('Username cannot be empty')
  ],
  authController.updateProfile
);

// ------------------- GET ACTIVITY LOG -------------------
router.get(
  '/activity-log',
  authMiddleware,
  authController.getActivityLog
);

module.exports = router;
