const db = require('../config/db');
const bcrypt = require('bcryptjs');

const User = {
  findByEmail: async (email) => {
    const [rows] = await db.query('SELECT * FROM users WHERE email = ?', [email]);
    return rows;
  },

  findById: async (id) => {
    const [rows] = await db.query('SELECT id, username, email, created_at FROM users WHERE id = ?', [id]);
    return rows[0];
  },

  create: async (username, email, hashedPassword) => {
    const [res] = await db.query('INSERT INTO users (username, email, password) VALUES (?, ?, ?)', [username, email, hashedPassword]);
    return res.insertId;
  },

  updateProfile: async (id, { username, email, passwordHash }) => {
    const updates = [];
    const params = [];
    if (username !== undefined) { updates.push('username = ?'); params.push(username); }
    if (email !== undefined) { updates.push('email = ?'); params.push(email); }
    if (passwordHash !== undefined) { updates.push('password = ?'); params.push(passwordHash); }
    if (!updates.length) return;
    params.push(id);
    const sql = `UPDATE users SET ${updates.join(', ')} WHERE id = ?`;
    await db.query(sql, params);
    return true;
  },

  isEmailTakenByOther: async (email, userId) => {
    const [rows] = await db.query('SELECT id FROM users WHERE email = ? AND id <> ? LIMIT 1', [email, userId]);
    return rows.length > 0;
  },

  setPasswordById: async (id, hashedPassword) => {
    await db.query('UPDATE users SET password = ? WHERE id = ?', [hashedPassword, id]);
  }
};

module.exports = User;
