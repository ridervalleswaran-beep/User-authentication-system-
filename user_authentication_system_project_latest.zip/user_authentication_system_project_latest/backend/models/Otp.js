const db = require('../config/db');
const bcrypt = require('bcryptjs');

const Otp = {
  create: async (userId, otpPlain, ttlMinutes = 5) => {
    const otpHash = await bcrypt.hash(otpPlain, 10);
    const expiresAt = new Date(Date.now() + ttlMinutes * 60 * 1000);
    const [res] = await db.query(
      'INSERT INTO otps (user_id, otp_hash, expires_at) VALUES (?, ?, ?)',
      [userId, otpHash, expiresAt]
    );
    return res.insertId;
  },

  findValid: async (userId) => {
    const [rows] = await db.query(
      'SELECT id, otp_hash, expires_at, used FROM otps WHERE user_id = ? ORDER BY created_at DESC LIMIT 1',
      [userId]
    );
    return rows[0];
  },

  markUsed: async (id) => {
    await db.query('UPDATE otps SET used = 1 WHERE id = ?', [id]);
  },

  deleteAllForUser: async (userId) => {
    await db.query('DELETE FROM otps WHERE user_id = ?', [userId]);
  }
};

module.exports = Otp;
