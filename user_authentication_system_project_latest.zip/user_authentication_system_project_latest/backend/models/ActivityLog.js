const db = require('../config/db');

const ActivityLog = {
  create: async (userId, action, meta = null) => {
    await db.query('INSERT INTO activity_logs (user_id, action, meta) VALUES (?, ?, ?)', [userId, action, JSON.stringify(meta)]);
  },

  listForUser: async (userId, limit = 50) => {
    const [rows] = await db.query('SELECT id, action, meta, created_at FROM activity_logs WHERE user_id = ? ORDER BY created_at DESC LIMIT ?', [userId, Number(limit)]);
    return rows.map(r => ({ ...r, meta: r.meta ? JSON.parse(r.meta) : null }));
  }
};

module.exports = ActivityLog;
