require('dotenv').config();
const express = require('express');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const cors = require('cors');
const path = require('path');

// backend routes
const authRoutes = require('./backend/routes/auth');

const app = express();
app.use(cors());
app.use(express.json());
app.use(helmet());

// Rate limiter for all /api routes (optional)
const apiLimiter = rateLimit({ windowMs: 15 * 60 * 1000, max: 200 });
app.use('/api/', apiLimiter);

// Use auth routes
app.use('/api/auth', authRoutes);

// Serve frontend
app.use('/frontend', express.static(path.join(__dirname, 'frontend')));

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Auth server listening on port ${port}`));
